export class Book {
    id : number;
    bookName : String;
    authorName :String ;
    price : number;

    constructor(id,bookName,authorName,price){
        this.id=id;
        this.bookName=bookName;
        this.authorName=authorName;
        this.price=price;
    }
}
