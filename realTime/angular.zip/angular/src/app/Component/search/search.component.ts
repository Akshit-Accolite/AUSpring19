import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/providers/book.service';
import { Book } from 'src/app/model/book';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {

  books: any = [];
  id:number;
  book : any;

  constructor(private bookService: BookService) { }

  ngOnInit() {
      this.bookService.getAllBooks().subscribe((response) => {
      console.log(response);
      if (response && response.length > 0) {
        this.books = response;
      }
    });
  }

  getBookId(){
    this.bookService.getBookById(this.id).subscribe((response) => {
      this.book = response;
    });
  }
  saveBookForCheckout(book:any){
    this.bookService.addBookToCheckout(new Book(book.id,book.bookName,book.authorName,book.price))
          .subscribe((response) => {
            console.log(response)
          });
  }
}
