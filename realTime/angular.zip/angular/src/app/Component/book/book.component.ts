import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BookService } from 'src/app/providers/book.service';
import { Book } from 'src/app/model/book';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.scss']
})
export class BookComponent implements OnInit {
  book:Book;
  bookId:any;
  books: any = [];

  constructor(private active : ActivatedRoute,private bookservice:BookService) { }

  ngOnInit() {
    // this.bookId = this.active.snapshot.paramMap.get('id');
    // this.bookservice.getBookById(this.bookId).subscribe((response)=>{
    //   console.log(response);
    //     this.book=response;
    // });
    this.bookservice.getAllBooksFromCheckout().subscribe((response) => {
      console.log(response);
      if (response && response.length > 0) {
        this.books = response;
      }
    });
  }
  getBookId(){
    this.bookservice.getBookById(this.bookId).subscribe((response) => {
      this.book = response;
    });
  }
  checkoutCart(){
    this.bookservice.checkout().subscribe((response) => {
      this.books=response;
    });
  }


  }


