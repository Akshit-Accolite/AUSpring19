import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/providers/book.service';
import { Book } from 'src/app/model/book';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  // books: any = [];
  // b: any;
  id: number;
  name: String;
  authorName: String;
  price: number;

  constructor(private bookService: BookService) { }

  ngOnInit() {
    // this.bookService.getAllBooks().subscribe((response) => {
    //   console.log(response);
    //   if (response && response.length > 0) {
    //     this.books = response;
    //   }
    // });

    // this.bookService.getBook().subscribe((response) => {
    //   console.log(response);

    //   this.b = response;

    // });
  }
  postData() {
    this.bookService.addBook(new Book(this.id,this.name,this.authorName,this.price))
          .subscribe((response) => {
            console.log(response)
          });
  }

}
