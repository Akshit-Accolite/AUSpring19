import { Injectable } from '@angular/core';
// import { HttpClient } from 'selenium-webdriver/http';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private http: HttpClient) { }

  getAllBooks(): Observable<any> {
    return this.http.get('/aulibrary/books');
  }

  getAllBooksFromCheckout() : Observable<any>{
    return this.http.get('aulibrary/checkouts');
  }

  getBook(): Observable<any> {
    return this.http.get('/aulibrary/book/1');
  }

  addBook(book: any): Observable<any> {
      console.log(book);
      return this.http.post("/aulibrary/books",book);
  }

  addBookToCheckout(book : any) : Observable <any> {
      console.log(book);
      return this.http.post("/aulibrary/checkout",book);
  }

  getBookById(id :any) : Observable<any> {
    return this.http.get("/aulibrary/book/"+id,id);
  }
  checkout() : Observable<any> {
    return this.http.get("/aulibrary/deleteBook");
  }

}
