package com.practice.hibernate;

import java.util.*;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.practice.pojo.Course;
import com.practice.pojo.Student;

public class App {
	
	public static void main(String[] args) {
		List<Student> studentList = new ArrayList<Student>();
		System.out.println("Hello World!");
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		session.beginTransaction();
		
		//for adding a new course
		Course c = new Course();
		c.setStudentId(2);
		c.setCourseName("Hibernate");
		c.setCourseId(3);
	//for adding a new student	
//		Student s = new Student();
//		s.setStudentId(78);
//		s.setStudentName("Akshit Arora");
//		s.setStudentAge(24);

//	Integer id = (Integer) session.save(c);
//		System.out.println(id);
		//for retrieving
		@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.eq("studentId",2));
		studentList = cr.list();
//		System.out.println(studentList.size());
//		ListIterator<Student> itr=studentList.listIterator();
//		while(itr.hasNext()) {
//			Student st=itr.next();
//			System.out.println(st.getStudentId() + "  "+st.getStudentName() + "  " +st.getStudentAge());
//		}
//		session.getTransaction().commit();
		for(Student student: studentList) {
			  System.out.println( student.getStudentName()+"|" 
			  +/*student.getStudentAge()*/"|"
			  +student.getStudentId()+"|"
			  +(!student.getCourses().isEmpty()?student.getCourses().get(0).getCourseName()
			  :"") ); }
//	}
}}
