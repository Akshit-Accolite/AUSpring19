package com.junit.pojo;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

public class Student implements Serializable  {
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

	int studentCode;

	String studentName;

	LocalDate dob;

	float studentPercentile;



	public int getStudentCode() {
		return studentCode;
	}

	public void setStudentCode(int studentCode) {
		this.studentCode = studentCode;
	}

	public String getStudentName() {
		return studentName;
	}

	public float getStudentPercentile() {
		return studentPercentile;
	}

	public void setStudentPercentile(float val) {
		this.studentPercentile = val;
	}

	public Student(int studentCode, String studentName, String dob, float studentPercentile) {
		this.studentCode = studentCode;
		this.studentName = studentName;
		this.dob =LocalDate.parse(dob);
		this.studentPercentile = studentPercentile;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

}
