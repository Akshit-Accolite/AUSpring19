package com.junit.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


public class Marks implements Serializable{


	int studentCode;


	String subjectName;


	int marks;


	public Marks(String subjectName,int studentCode,int marks) {
		this.marks=marks;
		this.studentCode=studentCode;
		this.marks=marks;
	}

	public int getStudentCode() {
		return studentCode;
	}


	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

}
