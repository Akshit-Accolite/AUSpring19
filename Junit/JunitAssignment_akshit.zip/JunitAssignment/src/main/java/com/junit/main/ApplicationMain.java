package com.junit.main;

import java.io.*;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.*;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.junit.pojo.Marks;
import com.junit.pojo.Student;

public class ApplicationMain {

	private static final String filepath_result = "Result.txt";
	private static final String filepath_student = "Student.txt";
	private static final String filepath_marks = "Marks.txt";

	public static void main(String args[]) {

		ApplicationMain applicationMain = new ApplicationMain();

		List<Student> stl = applicationMain.readStudents();

		List<Marks> listMarks = applicationMain.readMarks();

		List<Student> list = applicationMain.calPercentile(stl, listMarks);

	}

	public List<Student> readStudents() {
		//adding sttudents to file
		List<Student> stl1 = new ArrayList<Student>();
		stl1.add(new Student(1, "abc", "2009-12-31", 0));
		stl1.add(new Student(2, "def", "2007-12-31", 0));
		stl1.add(new Student(3, "ghi", "2007-10-31", 0));
		stl1.add(new Student(4, "jkl", "2001-12-31", 0));
		stl1.add(new Student(6, "jpqr", "2003-12-31", 0));
		stl1.add(new Student(7, "mno", "2009-12-31", 0));
		stl1.add(new Student(8, "xyz", "2000-10-31", 0));
		stl1.add(new Student(9, "stu", "2009-10-10", 0));
		stl1.add(new Student(10, "wvx", "2009-12-09", 0));

		writeObjectToFile(stl1, filepath_student);
		
		//now reading the file
		return ReadObjectFromFile(filepath_student);
	}

	public List<Marks> readMarks() {
		//adding the marks to file
		List<Marks> mkl = new ArrayList<Marks>();
		mkl.add(new Marks("s1", 1, 89));
		mkl.add(new Marks("s2", 1, 98));
		mkl.add(new Marks("s3", 1, 67));
		mkl.add(new Marks("s4", 1, 87));
		mkl.add(new Marks("s1", 2, 98));
		mkl.add(new Marks("s2", 2, 90));
		mkl.add(new Marks("s3", 2, 37));
		mkl.add(new Marks("s4", 2, 87));
		mkl.add(new Marks("s1", 3, 23));
		mkl.add(new Marks("s2", 3, 67));
		mkl.add(new Marks("s3", 3, 57));
		mkl.add(new Marks("s4", 3, 87));
		mkl.add(new Marks("s1", 4, 90));
		mkl.add(new Marks("s2", 4, 56));
		mkl.add(new Marks("s3", 4, 57));
		mkl.add(new Marks("s4", 4, 87));
		mkl.add(new Marks("s1", 6, 89));
		mkl.add(new Marks("s2", 6, 34));
		mkl.add(new Marks("s3", 6, 27));
		mkl.add(new Marks("s4", 6, 87));
		mkl.add(new Marks("s1", 7, 89));
		mkl.add(new Marks("s2", 7, 34));
		mkl.add(new Marks("s3", 7, 28));
		mkl.add(new Marks("s4", 7, 82));
		mkl.add(new Marks("s1", 8, 12));
		mkl.add(new Marks("s2", 8, 90));
		mkl.add(new Marks("s3", 8, 11));
		mkl.add(new Marks("s4", 8, 9));
		mkl.add(new Marks("s1", 9, 0));
		mkl.add(new Marks("s2", 9, 99));
		mkl.add(new Marks("s3", 9, 15));
		mkl.add(new Marks("s4", 9, 87));

		writeObjectToFile(mkl, filepath_marks);

		//reading the file
		return ReadObjectFromFile(filepath_marks);
	}

	public List<Student> calPercentile(List<Student> stl, List<Marks> listMarks) {

		for (Student s : stl) {
			int totalMark = 0;
			for (Marks m : listMarks) {
				if (s.getStudentCode() == m.getStudentCode()) {
					totalMark += m.getMarks();
				}
			}
			s.setStudentPercentile(totalMark);
		}

		float max = -1;
		for (Student s : stl) {
			if (s.getStudentPercentile() > (max)) {
				max = s.getStudentPercentile();
			}
		}

		System.out.println(max);

		for (Student s : stl) {
			float val = s.getStudentPercentile();
			val = (val / max) * 100;
			s.setStudentPercentile(val);
		}

		TreeSet<Student> sets = new TreeSet<Student>((p1,
				p2) -> (p1.getStudentPercentile() < p2.getStudentPercentile() ? 1
						: (p1.getStudentPercentile() == p2.getStudentPercentile() ? (p1.getDob().compareTo(p2.getDob()))
								: -1)));

		Iterator<Student> iterator = stl.iterator();
		while (iterator.hasNext()) {
			sets.add(iterator.next());
		}
		List<Student> stl1 = new ArrayList<>();

		for (Student s : sets) {
			stl1.add(s);
		}

		//writing the result to the file
		writeObjectToFile(stl1, filepath_result);

		//now reading the result
		readResult();

		return stl;
	}

	public void writeObjectToFile(List list, String filepath) {

		try {

			FileOutputStream fileOut = new FileOutputStream(filepath);

			ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);

			objectOut.writeObject(list);

			objectOut.close();

			System.out.println("The Object  was succesfully written to a file");

		} catch (Exception ex) {

			ex.printStackTrace();

		}

	}

	public List ReadObjectFromFile(String filepath) {

		List<Student> stl = new ArrayList();
		try {

			FileInputStream fileIn = new FileInputStream(filepath);

			ObjectInputStream objectIn = new ObjectInputStream(fileIn);

			Object obj = objectIn.readObject();

			System.out.println("The Object has been read from the file");

			objectIn.close();

			return (List) obj;

		} catch (Exception ex) {

			System.out.println("file not found");
			return null;

		}

	}

	public List<Student> readResult() {
		List<Student> temp = ReadObjectFromFile(filepath_result);
		for (Student s : temp) {
			System.out.println(
					s.getStudentName() + " " + s.getStudentPercentile() + " " + s.getDob() + " " + s.getStudentCode());
		}

		return temp;
	}

}
