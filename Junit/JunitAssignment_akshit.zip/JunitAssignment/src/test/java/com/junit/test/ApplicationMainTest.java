package com.junit.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.Mockito;

import com.junit.main.ApplicationMain;
import com.junit.pojo.Marks;
import com.junit.pojo.Student;

public class ApplicationMainTest {


	@Test
	public void testReadStudent() {
		ApplicationMain app = new ApplicationMain();
		List<Student> temp = app.readStudents();
		assertEquals(9, temp.size());
	}

	@Test
	public void testReadMarks() {
		ApplicationMain app = new ApplicationMain();
		List<Marks> temp = app.readMarks();
		assertEquals(32, temp.size());
	}

	@Test
	public void testCalPercentile() {

		ApplicationMain app = new ApplicationMain();
		List<Student> stl = app.readStudents();
		List<Marks> listMarks = app.readMarks();
		List<Student> stlRes = app.calPercentile(stl, listMarks);
		assertEquals(9, stlRes.size());

	}

}
