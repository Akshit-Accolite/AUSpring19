package org.accolite.java.EmployeeManagement.service;

import java.util.*;

import org.accolite.java.EmployeeManagement.dto.Employee;

public class EmployeeService {

	static ArrayList<Employee> a;

	public EmployeeService() {
		a = new ArrayList<>();
		a.add(new Employee("abc", 1, 45));
		a.add(new Employee("def", 3, 42));
		a.add(new Employee("ghi", 4, 32));
	}

	public Employee getEmployeeById(int id){
		for(Employee emp: a) 
			if(emp.getEmpId() == id)
				return emp;
		return null;
	}

	public ArrayList<Employee> getAllEmployee() {
		return a;
	}

	public String updateEmployee(Employee e) {
		boolean flag = false;
		Iterator<Employee> itr = a.iterator();
		while (itr.hasNext()) {
			Employee emp = itr.next();
			if (emp.getEmpId() == e.getEmpId()) {
				flag = true;
				emp.setEmpAge(e.getEmpAge());
				emp.setEmpName(e.getEmpName());
			}
		}
		if (flag)
			return "Updated";
		else
			return "no match found";
	}

	public void deleteEmployee(int id) {
		ArrayList<Employee> temp = new ArrayList<>();
		Iterator<Employee> itr = a.iterator();
		while (itr.hasNext()) {
			Employee e = itr.next();
			if (id != e.getEmpId()) {
				temp.add(e);
			}
		}
		if (a.size() > temp.size())
			System.out.println("Deleted");
		else
			System.out.println("no employee found");

		a = temp;
	}
}
