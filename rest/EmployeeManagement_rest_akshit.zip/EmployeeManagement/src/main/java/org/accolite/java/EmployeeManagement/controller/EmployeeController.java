package org.accolite.java.EmployeeManagement.controller;

import java.util.ArrayList;

//import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.accolite.java.EmployeeManagement.dto.Employee;
import org.accolite.java.EmployeeManagement.service.EmployeeService;

@Path("EmployeeController")
public class EmployeeController {

	static EmployeeService empSer = new EmployeeService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Employee> getIt() {
		System.out.println("fds");
		System.out.println(empSer.getAllEmployee());
		return empSer.getAllEmployee();
		// return "Got it!";
	}

	@GET
	@Path("{ID}")
	@Produces(MediaType.APPLICATION_JSON)
	public Employee getEmpByID(@PathParam("ID") int id) {
		System.out.println("in");
		return empSer.getEmployeeById(id);
	}

	@POST
	@Path("update")
	@Consumes({"application/xml", "application/json"})
	public String updatePath(Employee emp) {
			return empSer.updateEmployee(emp);
	}
	
	
	
}
