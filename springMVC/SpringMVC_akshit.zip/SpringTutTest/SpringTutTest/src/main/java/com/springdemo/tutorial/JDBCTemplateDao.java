package com.springdemo.tutorial;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;



@Component("jdbcTemplateDao")

public class JDBCTemplateDao {
	
//	JdbcTemplate template;    
//	
//	public void setTemplate(JdbcTemplate template) {    
//	    this.template = template;    
//	}    

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public int saveStudent(Student student) {
		System.out.println(student.getStudentId());
		String query = "insert into student(name,id) values " + "('" + student.getStudentName() + "',"
				+ student.getStudentId() + ")";
		System.out.println(query);
		return jdbcTemplate.update(query);
	}
	
	public List<Student> getAllStudentRowMapper() {
		return jdbcTemplate.query("select * from student", new RowMapper<Student>() {

			public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
				Student s=new Student();
				s.setStudentId(rs.getInt(2));
				s.setStudentName(rs.getString(1));
				return s;
			}

		});
	}
	
	public List<Student> getById(int id) {
		
		return jdbcTemplate.query("SELECT * FROM student where id = " + id,new RowMapper<Student>(){
			
		    public Student mapRow(ResultSet rs, int rownumber) throws SQLException {  
		        
		    	Student e=new Student();  
		        e.setStudentId(rs.getInt(2));  
		        e.setStudentName(rs.getString(1));   
		        return e;
		        
		    }  
	    
		});
		
	}
	
	public List<Student> getAllStudent(){
		return jdbcTemplate.query("SELECT * FROM student",new RowMapper<Student>() {

			@Override
			public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
				Student st=new Student();
				st.setStudentId(rs.getInt(2));
				st.setStudentName(rs.getString(1));
				return st;
			}
			
		});
	}

//	//Prepared Statement
//		public Boolean saveStudentUsingPreparedStatement(final Student student){
//			String query = "insert into Student(STUDENT_ID,STUDENT_NAME) values (?,?)";
//			return jdbcTemplate.execute(query, new PreparedStatementCallback<Boolean>() {
//
//				public Boolean doInPreparedStatement(PreparedStatement ps)
//						throws SQLException, DataAccessException {
//					ps.setInt(1, student.getStudentId());
//					ps.setString(2, student.getStudentName());
//					return ps.execute();
//				}
//			});
//		}

}
