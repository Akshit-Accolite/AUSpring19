package com.spring.au;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAu {

	public static void main(String[] args) {
		SpringApplication.run(SpringAu.class, args);
	}
	
}
