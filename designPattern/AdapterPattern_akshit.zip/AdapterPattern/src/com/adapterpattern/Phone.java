package com.adapterpattern;

public interface Phone {

	public void simCards();

	public void os();

}
