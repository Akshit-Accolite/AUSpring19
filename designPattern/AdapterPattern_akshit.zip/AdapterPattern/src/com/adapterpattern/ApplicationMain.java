package com.adapterpattern;

public class ApplicationMain {
	public static void main(String args[]) {
		Android android = new Android();
		android.simCards();
		android.os();
		
		Iphone iphone=new Iphone();
		iphone.simCards();
		iphone.os();
	}
}
