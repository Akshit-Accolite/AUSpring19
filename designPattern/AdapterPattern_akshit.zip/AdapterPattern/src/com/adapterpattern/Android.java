package com.adapterpattern;

public class Android implements Phone{

	@Override
	public void simCards() {
		System.out.println("Multi sim");
		
	}

	@Override
	public void os() {
		System.out.println("Android");
		
	}

}
