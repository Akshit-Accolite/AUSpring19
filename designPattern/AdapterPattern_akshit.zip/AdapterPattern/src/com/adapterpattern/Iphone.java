package com.adapterpattern;

public class Iphone implements Phone{
	@Override
	public void simCards() {
		System.out.println("Single sim");
		
	}

	@Override
	public void os() {
		System.out.println("IOS");
		
	}
}
