package com.oberverPattern;

public class FlightStatus extends BookingStatus {
	@Override
	public void updateStatus(boolean offer) {
		for (Observer observer : observers) {
			observer.update();
		}
	}

}
