package com.oberverPattern;

public class MainClass {
	public static void main(String args[]) {
		FlightStatus flightStatus=new FlightStatus();
		flightStatus.setDelay(true);
		flightStatus.updateStatus(true);
		
		System.out.println("=====================================");
		
		TrainStatus trainStatus=new TrainStatus();
		trainStatus.setDelay(false);
		trainStatus.updateStatus(false);
		
		System.out.println("=======================================");
	}

}
