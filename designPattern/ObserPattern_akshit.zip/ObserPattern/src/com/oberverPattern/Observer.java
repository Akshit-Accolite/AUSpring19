package com.oberverPattern;

public interface Observer {
	public void update();
}
