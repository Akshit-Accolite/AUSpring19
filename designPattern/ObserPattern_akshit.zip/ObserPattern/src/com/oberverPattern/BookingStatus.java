package com.oberverPattern;

import java.util.ArrayList;
import java.util.List;

public class BookingStatus {
	public List<Observer> observers = new ArrayList<>();
	boolean delay;
	public List<Observer> getObservers() {
		return observers;
	}
	public void setObservers(List<Observer> observers) {
		this.observers = observers;
	}
	public boolean isDelay() {
		return delay;
	}
	public void setDelay(boolean delay) {
		this.delay = delay;
	}
	
	public void notifyObserver() {
		
	}
	
	public void updateStatus(boolean offer) {
		this.setDelay(offer);
		this.notifyObserver();
}
	
	

}
