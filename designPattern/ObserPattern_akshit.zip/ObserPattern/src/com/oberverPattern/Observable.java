package com.oberverPattern;

public interface Observable {
	public void register();

	public void deRegister();

	public void notifyObservable();
}
