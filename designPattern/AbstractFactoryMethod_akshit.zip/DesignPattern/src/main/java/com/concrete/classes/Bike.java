package com.concrete.classes;

public interface Bike {
	
	
	public int getKmTravelled();

	public String getModelNumber();

	public String getRegNo();
	
}
