package com.concrete.classes;

public class SuzukiBike implements Bike{


	int kmTravelled;
	String regNo;
	String modelNumber;
	
	
	
	public SuzukiBike(int kmTravelled, String regNo, String modelNumber) {
		super();
		this.kmTravelled = kmTravelled;
		this.regNo = regNo;
		this.modelNumber = modelNumber;
	}


	public int getKmTravelled() {
		return this.kmTravelled;
	}


	public String getModelNumber() {
		return this.modelNumber;
	}

	public String getRegNo() {
		return this.regNo;
	}

}
