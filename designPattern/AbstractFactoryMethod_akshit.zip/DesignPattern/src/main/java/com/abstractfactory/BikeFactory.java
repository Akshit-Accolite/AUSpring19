package com.abstractfactory;

import com.concrete.classes.Bike;

public class BikeFactory {

		public static Bike createBike(AbstractFactoryClass af) {
			return af.createBike();
	}
}
