package com.abstractfactory;

import com.concrete.classes.Bike;

public interface AbstractFactoryClass {

	public  Bike createBike();
}
