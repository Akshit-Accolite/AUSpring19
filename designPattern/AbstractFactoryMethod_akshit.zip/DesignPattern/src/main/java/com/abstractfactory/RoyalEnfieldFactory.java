package com.abstractfactory;

import com.concrete.classes.Bike;
import com.concrete.classes.RoyalEnfield;

public class RoyalEnfieldFactory implements AbstractFactoryClass {

	int kmTravelled;
	String regNo;
	String modelNumber;
	public RoyalEnfieldFactory(int kmTravelled, String regNo, String modelNumber) {
		super();
		this.kmTravelled = kmTravelled;
		this.regNo = regNo;
		this.modelNumber = modelNumber;
	}
	public Bike createBike() {
		return new RoyalEnfield(this.kmTravelled,this.regNo,this.modelNumber);
	}
	
	
	
}
