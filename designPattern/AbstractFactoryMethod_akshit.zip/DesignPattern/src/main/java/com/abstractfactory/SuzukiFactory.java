package com.abstractfactory;

import com.concrete.classes.RoyalEnfield;
import com.concrete.classes.Bike;

public class SuzukiFactory implements AbstractFactoryClass{
	int kmTravelled;
	String regNo;
	String modelNumber;
	public SuzukiFactory(int kmTravelled, String regNo, String modelNumber) {
		super();
		this.kmTravelled = kmTravelled;
		this.regNo = regNo;
		this.modelNumber = modelNumber;
	}
	public Bike createBike() {
		return new RoyalEnfield(this.kmTravelled,this.regNo,this.modelNumber);
	}
	
}
