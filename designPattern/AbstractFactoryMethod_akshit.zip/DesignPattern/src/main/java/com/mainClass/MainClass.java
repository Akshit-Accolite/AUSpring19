package com.mainClass;

import com.abstractfactory.AbstractFactoryClass;
import com.abstractfactory.BikeFactory;
import com.abstractfactory.RoyalEnfieldFactory;
import com.abstractfactory.SuzukiFactory;
import com.concrete.classes.Bike;

public class MainClass {

	public static void main(String args[]) {
		Bike b1 = BikeFactory.createBike(new RoyalEnfieldFactory(200, "350", "2/78Gh"));

		Bike b2 = BikeFactory.createBike(new SuzukiFactory(50, "500", "2/4Yz"));
	}

}
