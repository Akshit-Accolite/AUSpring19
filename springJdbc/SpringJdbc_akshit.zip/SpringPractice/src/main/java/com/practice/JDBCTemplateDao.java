package com.practice;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class JDBCTemplateDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public int saveStudent(Student student) {
		String query = "insert into Student(name,id) values " + "('" + student.getName() + "'," + student.getId() + ")";
		return jdbcTemplate.update(query);
	}

	// using result set and extract method for select operation
	public List<Student> getAllStudents() {
		return jdbcTemplate.query("select * from student", new ResultSetExtractor<List<Student>>() {

			public List<Student> extractData(ResultSet rs) throws SQLException, DataAccessException {

				List<Student> list = new ArrayList<Student>();
				while (rs.next()) {
					Student stud = new Student();
					stud.setId(rs.getInt(2));
					stud.setName(rs.getString(1));

					list.add(stud);
				}
				return list;
			}
		});
	}

	// using row mapper 
	public List<Student> getAllStudentRowMapper() {
		return jdbcTemplate.query("select * from student", new RowMapper<Student>() {

			public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
				Student s=new Student();
				s.setId(rs.getInt(2));
				s.setName(rs.getString(1));
				return s;
			}

		});
	}

}
