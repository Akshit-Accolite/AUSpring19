package com.practice;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationMain {
	public static void main(String args[]) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("Beans.xml");
		
		JDBCTemplateDao jdbc=applicationContext.getBean(JDBCTemplateDao.class);
		List<Student> list=jdbc.getAllStudents();
		
		for(Student s:list) {
			System.out.println(s);
		}
		
		List<Student> listRowMapper=jdbc.getAllStudentRowMapper();
		for(Student s: listRowMapper) {
			System.out.println(s);
		}
		
//		Student stud=new Student();
//		stud.setId(3);
//		stud.setName("Puneet");
//		jdbc.saveStudent(stud);
	}
}
