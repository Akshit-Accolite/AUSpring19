package com.practice;

public class A {
	int a = 10;

	public static A getA() {
		System.out.println("inside getA method of A");
		return new A();
	}

}
