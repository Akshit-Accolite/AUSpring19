Taxi Stand
The Taxi file is the class of taxi which has its properties
The passenger class has the properties of passenger
The passengerRunnable generates new passenger
The taxiRunnable generates new taxi
